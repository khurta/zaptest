# AXA Materials

### Usage

`npm install @axa-ch/materials`

## Icon set

### Usage

```
import {
  ArrowRightSvg,
  CollapseSvg,
} from '@axa-ch/materials';
```

### Properties

| icon-set     |
| ------------ |
| CollapseSvg  |
| DateInputSvg |
| DownloadSvg  |
| EmailSvg     |
| ExpandSvg    |
| PhoneSvg     |
| PlusSvg      |
| SearchSvg    |
| UploadSvg    |
