import 'core-js/es6/reflect';
import 'core-js/es6/promise';
import 'core-js/fn/array/includes';
import 'core-js/fn/array/from';
import 'core-js/fn/object/assign';
import './index.webcomponents';
