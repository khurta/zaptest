import { createElement } from 'react';
import createAXADatepickerReact from '../index.react';

const AXADatepickerReact = createAXADatepickerReact(createElement);

export default AXADatepickerReact;
