export type icon =
  | 'collapse'
  | 'download'
  | 'email'
  | 'expand'
  | 'phone'
  | 'plus'
  | 'search'
  | 'upload';
