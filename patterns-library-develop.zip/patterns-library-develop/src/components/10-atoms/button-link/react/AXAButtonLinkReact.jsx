import { createElement } from 'react';
import createAXAButtonReact from '../index.react';

const AXAButtonLinkReact = createAXAButtonReact(createElement);

export default AXAButtonLinkReact;
