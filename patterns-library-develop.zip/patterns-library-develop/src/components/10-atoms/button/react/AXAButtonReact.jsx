import { createElement } from 'react';
import createAXAButtonReact from '../index.react';

const AXAButtonReact = createAXAButtonReact(createElement);

export default AXAButtonReact;
