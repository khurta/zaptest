import val from '@skatejs/val';

export default createElement => val(createElement);
