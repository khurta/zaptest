module.exports = [
  'components/00-materials/00-colors.scss',
  'components/00-materials/10-helpers.scss',
  'components/00-materials/20-typography-and-text.scss',
  'components/00-materials/30-layout.scss',
];
